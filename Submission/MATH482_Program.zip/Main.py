import Solver

Solver.main()
