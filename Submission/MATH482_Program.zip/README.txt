To run the solver, run "Main.py"

All status updates are output to minimalLogger.log in the program directory
	-Just close and reopen the file to see the most up-to-date info (or hit Ctrl+R if you're using Notepad++)
	-Only overarching updates are output in the program window - specifically, which puzzle is currently being processed

Resultant minimal obstacles *should* be output to minimalObstacles.txt